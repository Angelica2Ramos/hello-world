myValue=5j


print (" Python has three numeric types: int,float and complex")

print ('1')

print (str('1') + " is of the data type " + str('int'))

print (float('3.14'))

print (str('3.14') + " is of the data type " + str('float'))

print ('5j')

print (str("5j") +  " is of the data type "  + str('complex'))

myValue=True 

print (bool('True'))

print (str('True') + " is of the data type " + str('bool'))